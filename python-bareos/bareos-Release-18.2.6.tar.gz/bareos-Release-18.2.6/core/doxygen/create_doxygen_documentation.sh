#!/bin/bash
pushd ..
doxygen doxygen/bareos.doxy
popd
