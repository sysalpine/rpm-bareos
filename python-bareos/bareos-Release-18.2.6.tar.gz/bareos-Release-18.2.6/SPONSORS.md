Several companies helped to improve the Bareos project by funding parts of the development.

See https://www.bareos.com/en/co-funding.html for information about funded development.

See https://www.bareos.com/en/sponsors.html for information about Bareos sponsors.

